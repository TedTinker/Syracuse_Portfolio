The JSON "AllCards" holds the data used for the project, which is best explored in R-Studio.
The PDF "Ted_Tinker_final project" is the final poster, with visualizations process in Adobe Illustrator. 
The R-Script Ted_Tinker_final project", executed in R-Studio, processed the semistructured JSON-file to make visualizations with ggplot2.