# Ted Tinker
# Final Poster

library(jsonlite)
library(ggplot2)
library(wordcloud)
library(dplyr)

mtg_cards <- fromJSON("AllCards.json")

columns_of_interest = c(
  "Name",
  "White",
  "Blue",
  "Black",
  "Red",
  "Green",
  "Mana Cost",
  "Type",
  "Power",
  "Toughness")

rows = length(mtg_cards)
columns = length(columns_of_interest)
mtg_matrix <- matrix(ncol = columns, nrow = rows)
colnames(mtg_matrix) <- columns_of_interest

subtype_corpus <- c()

i = 1

for (card in mtg_cards) {
  if(!"UGL" %in% card$printings && !"UNH" %in% card$printings && !"UST" %in% card$printings) {
    mtg_matrix[i,"Name"] <- card$name
    id <- card$colorIdentity
    if("W" %in% id) {
      mtg_matrix[i,"White"] <- 1
    } else {
      mtg_matrix[i,"White"] <- 0
    }
    if("U" %in% id) {
      mtg_matrix[i,"Blue"] <- 1
    } else {
      mtg_matrix[i,"Blue"] <- 0
    }
    if("B" %in% id) {
      mtg_matrix[i,"Black"] <- 1
    } else {
      mtg_matrix[i,"Black"] <- 0
    }
    if("R" %in% id) {
      mtg_matrix[i,"Red"] <- 1
    } else {
      mtg_matrix[i,"Red"] <- 0
    }
    if("G" %in% id) {
      mtg_matrix[i,"Green"] <- 1
    } else {
      mtg_matrix[i,"Green"] <- 0
    }
    mtg_matrix[i, "Mana Cost"] <- as.integer(card$convertedManaCost)
    mtg_matrix[i, "Type"] <- card$types[1]
    for (subtype in card$subtypes) {
      subtype_corpus <- c(subtype_corpus, subtype)
    }
    if(!is.null(card$power)) {
      mtg_matrix[i, "Power"] <- card$power
    }
    if(!is.null(card$toughness)) {
      mtg_matrix[i, "Toughness"] <- card$toughness
    }
  }
  i = i + 1
}

mtg_matrix <- mtg_matrix[rowSums(is.na(mtg_matrix)) != ncol(mtg_matrix), ]

irregular_powers <- c()
irregular_toughnesses <- c()

add_weird_power_toughness <- function (card) {
  if(!is.na(card["Power"])) {
    if(is.na(as.numeric(card["Power"]))) {
      irregular_powers <<- c(irregular_powers, card["Power"])
    }
  }
  if(!is.na(card["Toughness"])) {
    if(is.na(as.numeric(card["Toughness"]))) {
      irregular_toughnesses <<- c(irregular_toughnesses, card["Toughness"])
    }
  }
}

f <- apply(mtg_matrix, 1, function(card) add_weird_power_toughness(card))

mtg_df <- data.frame(mtg_matrix, stringsAsFactors = FALSE)
mtg_df$White <- as.numeric(as.character(mtg_df$White))
mtg_df$Blue <- as.numeric(as.character(mtg_df$Blue))
mtg_df$Black <- as.numeric(as.character(mtg_df$Black))
mtg_df$Red <- as.numeric(as.character(mtg_df$Red))
mtg_df$Green <- as.numeric(as.character(mtg_df$Green))
mtg_df$Mana.Cost <- as.numeric(as.character(mtg_df$Mana.Cost))
mtg_df$Power <- as.numeric(as.character(mtg_df$Power))
mtg_df$Toughness <- as.numeric(as.character(mtg_df$Toughness))
mtg_df$Times.Printed <- as.numeric(as.character(mtg_df$Times.Printed))
sapply(mtg_df, mode)








# HISTOGRAM OF IRREGULAR POWERS
power_table <- table(irregular_powers)
power_table <- sort(power_table, decreasing = TRUE)
toughness_table <- table(irregular_toughnesses)
toughness_table <- toughness_table[c(names(power_table),"*+1", "7-*")]

par(mfrow = c(1,2))

barplot(
  power_table,
  ylim = c(0,150),
  main = "Counts of Irregular Power",
  col = "red",
  ylab = "Count",
  xlab = "Power"
)
barplot(
  toughness_table,
  ylim = c(0,150),
  main = "Counts of Irregular Toughness",
  col = "blue",
  xlab = "Toughness"
)







# MULTIDIMENSIONAL!
monocolor <- function(card) {
  color_count <- sum(card[,c("White", "Blue", "Black", "Red", "Green")])
  return(color_count == 1 || color_count == 0)
}

which_color <- function(card) {
  if(card$White == 1) {
    return("White")
  }
  if(card$Blue == 1) {
    return("Blue")
  }
  if(card$Black == 1) {
    return("Black")
  }
  if(card$Red == 1) {
    return("Red")
  }
  if(card$Green == 1) {
    return("DarkGreen")
  }
  return("gray")
}

is_it_monocolor <- c()
for (i in 1:nrow(mtg_df)) {
  is_it_monocolor <- c(is_it_monocolor, monocolor(mtg_df[i,]))
}

mtg_monocolor <- mtg_df[is_it_monocolor,]

which_monocolor <- c()
for (i in 1:nrow(mtg_monocolor)) {
  which_monocolor <- c(which_monocolor, which_color(mtg_monocolor[i,]))
}
mtg_monocolor$Color <- which_monocolor

cpt_table <- table(mtg_monocolor[,c("Power", "Toughness", "Color")])
cpt_df <- as.data.frame(cpt_table)

legend_dummies <- data.frame(
  c(14,14,14,14,14,14,14,14,14,14),
  c(10,9.5,8.8,8,3,3,3,3,3,3),
  c("Black", "Black", "Black", "Black", "White", "Blue", "Black", "Red", "DarkGreen", "gray"),
  c(1,10,100,1000,50,50,50,50,50,50)
)
names(legend_dummies) <- c("Power", "Toughness", "Color", "Freq")
cpt_df <- rbind(legend_dummies, cpt_df)

cpt_df$Power <- as.numeric(as.character(cpt_df$Power))
cpt_df$Toughness <- as.numeric(as.character(cpt_df$Toughness))
cpt_df$log_Freq <- log(cpt_df$Freq + 5)
cpt_df$log_Freq[cpt_df$Freq == 0] <- -Inf

for (i in 1:nrow(cpt_df)) {
  if(cpt_df[i,"Color"] == "White") {
    edit_p <- 0
    edit_t <- 1
  } else if(cpt_df[i,"Color"] == "Blue") {
    edit_p <- .95
    edit_t <- .3
  } else if(cpt_df[i,"Color"] == "Black") {
    edit_p <- .6
    edit_t <- -.8
  } else if(cpt_df[i,"Color"] == "Red") {
    edit_p <- -.6
    edit_t <- -.8
  } else if(cpt_df[i,"Color"] == "DarkGreen"){
    edit_p <- -.95
    edit_t <- .3
  }
  edit_p <- edit_p * .25
  edit_t <- edit_t * .25
  cpt_df[i,"Power"] = cpt_df[i,"Power"] + edit_p
  cpt_df[i,"Toughness"] = cpt_df[i,"Toughness"] + edit_t
}

cpt_df$Outline <- rep("NULL", nrow(cpt_df))

for (i in 1:nrow(cpt_df)) {
  if(cpt_df[i,"Color"] == "White") {
    cpt_df[i,"Outline"] <- "gray"
  } else if(cpt_df[i,"Color"] == "Blue") {
    cpt_df[i,"Outline"] <- "Blue"
  } else if(cpt_df[i,"Color"] == "Black") {
    cpt_df[i,"Outline"] <- "Black"
  } else if(cpt_df[i,"Color"] == "Red") {
    cpt_df[i,"Outline"] <- "Red"
  } else if(cpt_df[i,"Color"] == "DarkGreen"){
    cpt_df[i,"Outline"] <- "DarkGreen"
  } else {
    cpt_df[i,"Outline"] <- "gray"
  }
}

cpt_df <- rbind(
    cpt_df[cpt_df$Color == "White",],
    cpt_df[cpt_df$Color == "Blue",],
    cpt_df[cpt_df$Color == "Black",],
    cpt_df[cpt_df$Color == "Red",],
    cpt_df[cpt_df$Color == "DarkGreen",],
    cpt_df[cpt_df$Color == "gray",]
)

ggplot(cpt_df) +
  aes(x = Power, y = Toughness) +
  geom_point(
    pch = 21,
    fill = cpt_df$Color, 
    colour = cpt_df$Outline,
    size = 1.4*cpt_df$log_Freq,
    alpha = .6) +
  ggtitle("Power/Toughness Frequency by Color (Multidimensional)") +
  scale_x_continuous(breaks = seq(0, 16, by = 1)) +
  scale_y_continuous(breaks = seq(0, 16, by = 1)) + 
  geom_abline(slope=1, intercept=0, col = "gray") 





# BOXPLOTS OF COLORS' MANA COST
mtg_c = mtg_monocolor[mtg_monocolor$Color == "gray",]
mtg_w = mtg_monocolor[mtg_monocolor$Color == "White",]
mtg_u = mtg_monocolor[mtg_monocolor$Color == "Blue",]
mtg_b = mtg_monocolor[mtg_monocolor$Color == "Black",]
mtg_r = mtg_monocolor[mtg_monocolor$Color == "Red",]
mtg_g = mtg_monocolor[mtg_monocolor$Color == "DarkGreen",]

mtg_c <- mutate(mtg_c, outlier = Mana.Cost > 10)
mtg_w <- mutate(mtg_w, outlier = Mana.Cost > 7)
mtg_u <- mutate(mtg_u, outlier = Mana.Cost > 7)
mtg_b <- mutate(mtg_b, outlier = Mana.Cost > 7)
mtg_r <- mutate(mtg_r, outlier = Mana.Cost > 7)
mtg_g <- mutate(mtg_g, outlier = Mana.Cost > 7)


ggplot() +
  geom_violin(data = mtg_c, aes(y = Mana.Cost, x = 0), fill = "gray", outlier.shape = NA, bw = .5) +
  geom_point(data = mtg_c[mtg_c$outlier,], aes(y = Mana.Cost, x = 0), position = "jitter", col = "gray70") + 
  geom_violin(data = mtg_w, aes(y = Mana.Cost, x = 1), fill = "white", outlier.shape = NA, bw = .5) +
  geom_point(data = mtg_w[mtg_w$outlier,], aes(y = Mana.Cost, x = 1), position = "jitter", col = "gray70") + 
  geom_violin(data = mtg_u, aes(y = Mana.Cost, x = 2), fill = "blue", outlier.shape = NA, bw = .5) +
  geom_point(data = mtg_u[mtg_u$outlier,], aes(y = Mana.Cost, x = 2), position = "jitter", col = "blue") +
  geom_violin(data = mtg_b, aes(y = Mana.Cost, x = 3), fill = "gray40", outlier.shape = NA, bw = .5) +
  geom_point(data = mtg_b[mtg_b$outlier,], aes(y = Mana.Cost, x = 3), position = "jitter", col = "black") +
  geom_violin(data = mtg_r, aes(y = Mana.Cost, x = 4), fill = "red", outlier.shape = NA, bw = .5) +
  geom_point(data = mtg_r[mtg_r$outlier,], aes(y = Mana.Cost, x = 4), position = "jitter", col = "red") +
  geom_violin(data = mtg_g, aes(y = Mana.Cost, x = 5), fill = "darkgreen", outlier.shape = NA, bw = .5) + 
  geom_point(data = mtg_g[mtg_g$outlier,], aes(y = Mana.Cost, x = 5), position = "jitter", col = "darkgreen") +
  xlab("") + ylab("Mana Cost") + ggtitle("Mana-Cost by Color") +
  scale_y_continuous(breaks = seq(0, 16, by = 1)) 






# HISTOGRAMS OF CARD TYPES
type_counts <- table(mtg_monocolor$Type)
type_counts <- sort(type_counts, decreasing = TRUE)

card_types <- names(type_counts)[1:5]
color_list = c("gray", "white", "blue", "black", "red", "DarkGreen")

c_type_counts <- table(mtg_c$Type)
w_type_counts <- table(mtg_w$Type)
u_type_counts <- table(mtg_u$Type)
b_type_counts <- table(mtg_b$Type)
r_type_counts <- table(mtg_r$Type)
g_type_counts <- table(mtg_g$Type)

c_type_counts <- c_type_counts[card_types]
w_type_counts <- w_type_counts[card_types]
u_type_counts <- u_type_counts[card_types]
b_type_counts <- b_type_counts[card_types]
r_type_counts <- r_type_counts[card_types]
g_type_counts <- g_type_counts[card_types]

creatures <- rbind(
  c_type_counts["Creature"],
  w_type_counts["Creature"],
  u_type_counts["Creature"],
  b_type_counts["Creature"],
  r_type_counts["Creature"],
  g_type_counts["Creature"]
  )
enchants <- rbind(
  c_type_counts["Enchantment"],
  w_type_counts["Enchantment"],
  u_type_counts["Enchantment"],
  b_type_counts["Enchantment"],
  r_type_counts["Enchantment"],
  g_type_counts["Enchantment"]
)
instants <- rbind(
  c_type_counts["Instant"],
  w_type_counts["Instant"],
  u_type_counts["Instant"],
  b_type_counts["Instant"],
  r_type_counts["Instant"],
  g_type_counts["Instant"]
)
sorceries <- rbind(
  c_type_counts["Sorcery"],
  w_type_counts["Sorcery"],
  u_type_counts["Sorcery"],
  b_type_counts["Sorcery"],
  r_type_counts["Sorcery"],
  g_type_counts["Sorcery"]
)
artifacts <- rbind(
  c_type_counts["Artifact"],
  w_type_counts["Artifact"],
  u_type_counts["Artifact"],
  b_type_counts["Artifact"],
  r_type_counts["Artifact"],
  g_type_counts["Artifact"]
)


par(mfrow = c(1,5))

barplot(
  creatures
  , las = 2
  , col = color_list
  , ylab = "Count"
  , ylim = c(0,2000)
  , main = "Creatures by Color"
  , beside = TRUE
)
barplot(
  enchants
  , las = 2
  , col = color_list
  , ylab = "Count"
  , ylim = c(0,2000)
  , main = "Enchantments by Color"
  , beside = TRUE
)
barplot(
  instants
  , las = 2
  , col = color_list
  , ylab = "Count"
  , ylim = c(0,2000)
  , main = "Instants by Color"
  , beside = TRUE
)
barplot(
  sorceries
  , las = 2
  , col = color_list
  , ylab = "Count"
  , ylim = c(0,2000)
  , main = "Sorceries by Color"
  , beside = TRUE
)
barplot(
  artifacts
  , las = 2
  , col = color_list
  , ylab = "Count"
  , ylim = c(0,2000)
  , main = "Artifacts by Color"
  , beside = TRUE
)



### Barplot---color counts
mtg_df$col_count <- mtg_df$White + mtg_df$Blue + mtg_df$Black + mtg_df$Red + mtg_df$Green

col_count_table <- table(mtg_df$col_count)

par(mfrow(1,1))
barplot(
  col_count_table
  , las = 2
  , ylab = "Count"
  , main = "Number of Colors in Color-Identities"
  , beside = TRUE
)