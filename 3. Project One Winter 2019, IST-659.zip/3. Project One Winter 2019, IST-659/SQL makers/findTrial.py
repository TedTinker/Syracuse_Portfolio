# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import pandas as pd
from dateutil import parser

default_date = parser.parse('1/1/1400')


os.chdir('C:\\Users\\tedjt\\Desktop\\School\\Analysis\\WitchCraft')

Trial = 'Trial.xlsx'
TrialFile = pd.read_excel(Trial)
TrialFile.iloc[:,[32,37]] = TrialFile.iloc[:,[32,37]].fillna('Unknown')
TrialFile.iloc[:,[33,34]] = TrialFile.iloc[:,[33,34]].fillna(0)
TrialFile = TrialFile.fillna('')

InsertStatement = ''

for row in range(0,TrialFile.shape[0]):
    InsertStatement += 'INSERT INTO Trial (Trial_Ref, Case_ID,Parish_ID, Arrest, Arrest_Date,Fled,Fled_Date,Action_Dropped,Action_Drop_Date,Trial_Date,Trial_Place,Female_Accusers,Male_Accusers, Verdict, Sentence, Execution, Execution_Parish_ID,Execution_Method,Execution_Date,Execution_County,Execution_Burgh,Pretrial_Notes,Posttrial_Notes)\nVALUES'
    Trial_Ref = '\'' + str(TrialFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(TrialFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    if(TrialFile.iloc[row,6]==''):
        Parish_ID = 'NULL, '
    else:
        Parish_ID = '(SELECT Parish_ID FROM Ref_Parish WHERE Parish_Ref = \'' + str(TrialFile.iloc[row,6]).replace('\'','\'\'') + '\'), '
    if(TrialFile.iloc[row,16] == False):
       Arrest = '0, '
    else:
        Arrest = '1, '
    if(TrialFile.iloc[row,17]==''):
        Arrest_Date = 'NULL, '
    else:
        Arrest_Date = '\'' + str(parser.parse(str(TrialFile.iloc[row,17]).replace('\'','\'\''), default=default_date).date()) + '\', '
    if(TrialFile.iloc[row,19] == False):
        Fled = '0, '
    else:
        Fled = '1, '    
    if(TrialFile.iloc[row,20]==''):
        Fled_Date = 'NULL, '
    else:
        Fled_Date = '\'' + str(parser.parse(str(TrialFile.iloc[row,20]).replace('\'','\'\''), default=default_date).date()) + '\', '
    if(TrialFile.iloc[row,22] == False):
        Action_Dropped = '0, '
    else:
        Action_Dropped = '1, '
    if(TrialFile.iloc[row,23]==''):
        Action_Drop_Date = 'NULL, '
    else:
        Action_Drop_Date = '\'' + str(parser.parse(str(TrialFile.iloc[row,23]).replace('\'','\'\''), default=default_date).date()) + '\', '
    if(TrialFile.iloc[row,30]==''):
        Trial_Date = 'NULL, '
    else:
        Trial_Date = '\'' + str(parser.parse(str(TrialFile.iloc[row,30]).replace('\'','\'\''), default=default_date).date()) + '\', '
    Trial_Place = '\'' + str(TrialFile.iloc[row,32]).replace('\'','\'\'') + '\', '
    Female_Accusers = str(TrialFile.iloc[row,33]).replace('\'','\'\'') + ', '
    Male_Accusers = str(TrialFile.iloc[row,34]).replace('\'','\'\'') + ', '
    Verdict = '\'' + str(TrialFile.iloc[row,37]).replace('\'','\'\'') + '\', '
    if(TrialFile.iloc[row,38]==''):
        Sentence = 'NULL, '
    else:
        Sentence = '\'' + str(TrialFile.iloc[row,38]).replace('\'','\'\'') + '\', '
    Execution = '\'' + str(TrialFile.iloc[row,47]).replace('\'','\'\'') + '\', '
    if(TrialFile.iloc[row,53]==''):
        Execution_Parish_ID = 'NULL, '
    else:
        Execution_Parish_ID = '(SELECT Parish_ID FROM Ref_Parish WHERE Parish_Ref = \'' + str(TrialFile.iloc[row,53]).replace('\'','\'\'') + '\'), '
    if(TrialFile.iloc[row,48]==''):
        Execution_Method = 'NULL, '
    else:
        Execution_Method = '\'' + str(TrialFile.iloc[row,48]).replace('\'','\'\'') + '\', '
    if(TrialFile.iloc[row,49]==''):
        Execution_Date = 'NULL, '
    else:
        Execution_Date = '\'' + str(parser.parse(str(TrialFile.iloc[row,49]).replace('\'','\'\''), default=default_date).date()) + '\', '
    if(TrialFile.iloc[row,55]==''):
        Execution_County = 'NULL, '
    else:
        Execution_County = '\'' + str(TrialFile.iloc[row,55]).replace('\'','\'\'') + '\', '
    if(TrialFile.iloc[row,56]==''):
        Execution_Burgh = 'NULL, '
    else:
        Execution_Burgh = '\'' + str(TrialFile.iloc[row,56]).replace('\'','\'\'') + '\', '
    if(TrialFile.iloc[row,28]==''):
        Pretrial_Notes = 'NULL, '
    else:
        Pretrial_Notes = '\'' + str(TrialFile.iloc[row,28]).replace('\'','\'\'') + '\', '
    if(TrialFile.iloc[row,60]==''):
        Posttrial_Notes = 'NULL'
    else:
        Posttrial_Notes = '\'' + str(TrialFile.iloc[row,60]).replace('\'','\'\'') + '\''
    
    InsertStatement += '(' + Trial_Ref + Case_ID + Parish_ID + Arrest + Arrest_Date + Fled + Fled_Date + Action_Dropped + Action_Drop_Date + Trial_Date + Trial_Place + Female_Accusers + Male_Accusers + Verdict + Sentence + Execution + Execution_Parish_ID + Execution_Method + Execution_Date + Execution_County + Execution_Burgh + Pretrial_Notes + Posttrial_Notes + ');\n'
    
    
    
print(InsertStatement)