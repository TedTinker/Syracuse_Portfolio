# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import pandas as pd

os.chdir('C:\\Users\\tedjt\\Desktop\\School\\Analysis\\WitchCraft')

refParish = 'Ref_Parish.xlsx'
ParishFile = pd.read_excel(refParish)
ParishFile = ParishFile.fillna('Unknown')

InsertStatement = ''

for row in range(0,ParishFile.shape[0]):
    InsertStatement += 'INSERT INTO Ref_Parish (Parish_Ref,Parish_Name, County, Burgh)\nVALUES ('
    Parish_Ref = '\'' + str(ParishFile.iloc[row,0]).replace('\'','\'\'') + '\','
    Parish_Name = '\'' + str(ParishFile.iloc[row,3]).replace('\'','\'\'') + '\','
    County = '\'' + str(ParishFile.iloc[row,8]).replace('\'','\'\'') + '\','
    Burgh = '\'' + str(ParishFile.iloc[row,9]).replace('\'','\'\'') + '\''
    InsertStatement += Parish_Ref + Parish_Name + County + Burgh + ');\n'
    
# InsertStatement = InsertStatement[:-2] + ';'
    
    
print(InsertStatement)