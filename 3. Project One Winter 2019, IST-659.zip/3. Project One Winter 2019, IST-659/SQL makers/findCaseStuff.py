# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import pandas as pd
from dateutil import parser

default_date = parser.parse('1/1/1400')

os.chdir('C:\\Users\\tedjt\\Desktop\\School\\Analysis\\WitchCraft')




Demonic_Pact = 'Demonic_Pact.xlsx'
Demonic_PactFile = pd.read_excel(Demonic_Pact)
Demonic_PactFile.iloc[:,[4]] = Demonic_PactFile.iloc[:,[4]].fillna('Unknown')
Demonic_PactFile = Demonic_PactFile.fillna('')

InsertStatement = ''

for row in range(0,Demonic_PactFile.shape[0]):
    InsertStatement += 'INSERT INTO Demonic_Pact (Demonic_Ref,Case_ID,Demonic_Type,Notes)\nVALUES'
    
    Demonic_Ref = '\'' + str(Demonic_PactFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Demonic_PactFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Demonic_Type = '\'' + str(Demonic_PactFile.iloc[row,4]).replace('\'','\'\'') + '\', '
    if(Demonic_PactFile.iloc[row,5]==''):
        Notes = 'NULL'
    else:
        Notes = '\'' + str(Demonic_PactFile.iloc[row,5]).replace('\'','\'\'') + '\''
    
    InsertStatement += '(' + Demonic_Ref + Case_ID + Demonic_Type + Notes   + ');\n'
    
    
    
    
Devil_Appearence = 'Devil_Appearence.xlsx'
Devil_AppearenceFile = pd.read_excel(Devil_Appearence)
Devil_AppearenceFile.iloc[:,[4]] = Devil_AppearenceFile.iloc[:,[4]].fillna('Unknown')
Devil_AppearenceFile = Devil_AppearenceFile.fillna('')


for row in range(0,Devil_AppearenceFile.shape[0]):
    InsertStatement += 'INSERT INTO Devil_Appearence (Devil_Ref,Case_ID,Devil_Type,Notes)\nVALUES'
    
    Devil_Ref = '\'' + str(Devil_AppearenceFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Devil_AppearenceFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Devil_Type = '\'' + str(Devil_AppearenceFile.iloc[row,4]).replace('\'','\'\'') + '\', '
    if(Devil_AppearenceFile.iloc[row,5]==''):
        Notes = 'NULL'
    else:
        Notes = '\'' + str(Devil_AppearenceFile.iloc[row,5]).replace('\'','\'\'') + '\''
    
    InsertStatement += '(' + Devil_Ref + Case_ID + Devil_Type + Notes + ');\n'
    
    
    
    
    
Religious_Motif = 'Religious_Motif.xlsx'
Religious_MotifFile = pd.read_excel(Religious_Motif)
Religious_MotifFile = Religious_MotifFile.fillna('')


    
for row in range(0,Religious_MotifFile.shape[0]):
    InsertStatement += 'INSERT INTO Religious_Motif (Motif_Ref,Case_ID,Motif_Type)\nVALUES'
    
    Motif_Ref = '\'' + str(Religious_MotifFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Religious_MotifFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Motif_Type = '\'' + str(Religious_MotifFile.iloc[row,4]).replace('\'','\'\'') + '\''

    InsertStatement += '(' + Motif_Ref + Case_ID + Motif_Type + ');\n'
    
    
    
    
    
Ritual_Object = 'Ritual_Object.xlsx'
Ritual_ObjectFile = pd.read_excel(Ritual_Object)
Ritual_ObjectFile.iloc[:,[4]] = Ritual_ObjectFile.iloc[:,[4]].fillna('Unknown')
Ritual_ObjectFile = Ritual_ObjectFile.fillna('')


for row in range(0,Ritual_ObjectFile.shape[0]):
    InsertStatement += 'INSERT INTO Ritual_Object (Ritual_Object_Ref,Case_ID,Ritual_Object_Type)\nVALUES'
    
    Ritual_Object_Ref = '\'' + str(Ritual_ObjectFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Ritual_ObjectFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Ritual_Object_Type = '\'' + str(Ritual_ObjectFile.iloc[row,4]).replace('\'','\'\'') + '\' '

    InsertStatement += '(' + Ritual_Object_Ref + Case_ID + Ritual_Object_Type + ');\n'
    
    
    
    
Elf_Fairy_Elements = 'Elf_Fairy_Elements.xlsx'
Elf_Fairy_ElementsFile = pd.read_excel(Elf_Fairy_Elements)
Elf_Fairy_ElementsFile.iloc[:,[4]] = Elf_Fairy_ElementsFile.iloc[:,[4]].fillna('Unknown')
Elf_Fairy_ElementsFile = Elf_Fairy_ElementsFile.fillna('')



for row in range(0,Elf_Fairy_ElementsFile.shape[0]):
    InsertStatement += 'INSERT INTO Elf_Fairy_Elements (Elf_Fairy_Ref,Case_ID,Elf_Fairy_Type)\nVALUES'
    
    Elf_Fairy_Ref = '\'' + str(Elf_Fairy_ElementsFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Elf_Fairy_ElementsFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Elf_Fairy_Type = '\'' + str(Elf_Fairy_ElementsFile.iloc[row,4]).replace('\'','\'\'') + '\' '

    InsertStatement += '(' + Elf_Fairy_Ref + Case_ID + Elf_Fairy_Type + ');\n'
    
    
    
    
    
Malice = 'Malice.xlsx'
MaliceFile = pd.read_excel(Malice)
MaliceFile.iloc[:,[4]] = MaliceFile.iloc[:,[4]].fillna('Unknown')
MaliceFile = MaliceFile.fillna('')


for row in range(0,MaliceFile.shape[0]):
    InsertStatement += 'INSERT INTO Malice (Malice_Ref,Case_ID,Cause_of_Malice)\nVALUES'
    
    Malice_Ref = '\'' + str(MaliceFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(MaliceFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Cause_of_Malice = '\'' + str(MaliceFile.iloc[row,4]).replace('\'','\'\'') + '\''

    InsertStatement += '(' + Malice_Ref + Case_ID + Cause_of_Malice + ');\n'
    
    
    
    
Property_Damage = 'Property_Damage.xlsx'
Property_DamageFile = pd.read_excel(Property_Damage)
Property_DamageFile.iloc[:,[4]] = Property_DamageFile.iloc[:,[4]].fillna('Unknown')
Property_DamageFile = Property_DamageFile.fillna('')


for row in range(0,Property_DamageFile.shape[0]):
    InsertStatement += 'INSERT INTO Property_Damage (Property_Damage_Ref,Case_ID,Property_Damage_Type)\nVALUES'
    
    Property_Damage_Ref = '\'' + str(Property_DamageFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Property_DamageFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Property_Damage_Type = '\'' + str(Property_DamageFile.iloc[row,4]).replace('\'','\'\'') + '\''

    InsertStatement += '(' + Property_Damage_Ref + Case_ID + Property_Damage_Type + ');\n'
    
    
    
    
    
    
Weather_Modification = 'Weather_Modification.xlsx'
Weather_ModificationFile = pd.read_excel(Weather_Modification)
Weather_ModificationFile.iloc[:,[4]] = Weather_ModificationFile.iloc[:,[4]].fillna('Unknown')
Weather_ModificationFile = Weather_ModificationFile.fillna('')


for row in range(0,Weather_ModificationFile.shape[0]):
    InsertStatement += 'INSERT INTO Weather_Modification (Weather_Modification_Ref,Case_ID, Weather_Modification_Type )\nVALUES'
    
    Weather_Modification_Ref = '\'' + str(Weather_ModificationFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Weather_ModificationFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Weather_Modification_Type = '\'' + str(Weather_ModificationFile.iloc[row,4]).replace('\'','\'\'') + '\''

    InsertStatement += '(' + Weather_Modification_Ref + Case_ID + Weather_Modification_Type  + ');\n'
    
    
    
    
    
Shape_Changing = 'Shape_Changing.xlsx'
Shape_ChangingFile = pd.read_excel(Shape_Changing)
Shape_ChangingFile.iloc[:,[4]] = Shape_ChangingFile.iloc[:,[4]].fillna('Unknown')
Shape_ChangingFile = Shape_ChangingFile.fillna('')
    

for row in range(0,Shape_ChangingFile.shape[0]):
    InsertStatement += 'INSERT INTO Shape_Changing (Shape_Changing_Ref,Case_ID,Shapechanging_Type,Notes)\nVALUES'
    
    Shape_Changing_Ref = '\'' + str(Shape_ChangingFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Shape_ChangingFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Shapechanging_Type = '\'' + str(Shape_ChangingFile.iloc[row,4]).replace('\'','\'\'') + '\', '
    if(Shape_ChangingFile.iloc[row,5]==''):
        Notes = 'NULL'
    else:
        Notes = '\'' + str(Shape_ChangingFile.iloc[row,5]).replace('\'','\'\'') + '\''
    
    InsertStatement += '(' + Shape_Changing_Ref + Case_ID + Shapechanging_Type + Notes + ');\n'
    
    
    
    
White_Magic = 'White_Magic.xlsx'
White_MagicFile = pd.read_excel(White_Magic)
White_MagicFile.iloc[:,[4]] = White_MagicFile.iloc[:,[4]].fillna('Unknown')
White_MagicFile = White_MagicFile.fillna('')


for row in range(0,White_MagicFile.shape[0]):
    InsertStatement += 'INSERT INTO White_Magic (White_Magic_Ref,Case_ID,White_Magic_Type)\nVALUES'
    
    White_Magic_Ref = '\'' + str(White_MagicFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(White_MagicFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    White_Magic_Type = '\'' + str(White_MagicFile.iloc[row,4]).replace('\'','\'\'') + '\''

    InsertStatement += '(' + White_Magic_Ref + Case_ID + White_Magic_Type + ');\n'
    
    
    

Counter_Strategy = 'Counter_Strategy.xlsx'
Counter_StrategyFile = pd.read_excel(Counter_Strategy)
Counter_StrategyFile.iloc[:,[4]] = Counter_StrategyFile.iloc[:,[4]].fillna('Unknown')
Counter_StrategyFile = Counter_StrategyFile.fillna('')


for row in range(0,Counter_StrategyFile.shape[0]):
    InsertStatement += 'INSERT INTO Counter_Strategy (Counter_Strategy_Ref,Case_ID,Type)\nVALUES'
    
    Counter_Strategy_Ref = '\'' + str(Counter_StrategyFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Counter_StrategyFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Type = '\'' + str(Counter_StrategyFile.iloc[row,4]).replace('\'','\'\'') + '\''
    
    InsertStatement += '(' + Counter_Strategy_Ref + Case_ID + Type + ');\n'
    
    
    

Musical_Instrument = 'Musical_Instrument.xlsx'
Musical_InstrumentFile = pd.read_excel(Musical_Instrument)
Musical_InstrumentFile.iloc[:,[4]] = Musical_InstrumentFile.iloc[:,[4]].fillna('Unknown')
Musical_InstrumentFile = Musical_InstrumentFile.fillna('')


for row in range(0,Musical_InstrumentFile.shape[0]):
    InsertStatement += 'INSERT INTO Musical_Instrument (Musical_Instrument_Ref,Case_ID,Musical_Instrument_Type,Musical_Instrument_Text)\nVALUES'
    
    Musical_Instrument_Ref = '\'' + str(Musical_InstrumentFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Musical_InstrumentFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Musical_Instrument_Type = '\'' + str(Musical_InstrumentFile.iloc[row,4]).replace('\'','\'\'') + '\', '
    if(Musical_InstrumentFile.iloc[row,5]==''):
        Musical_Instrument_Text = 'NULL'
    else:
        Musical_Instrument_Text = '\'' + str(Musical_InstrumentFile.iloc[row,5]).replace('\'','\'\'') + '\''
    
    InsertStatement += '(' + Musical_Instrument_Ref + Case_ID + Musical_Instrument_Type + Musical_Instrument_Text + ');\n'




Calendar_Custom = 'Calendar_Custom.xlsx'
Calendar_CustomFile = pd.read_excel(Calendar_Custom)
Calendar_CustomFile.iloc[:,[4]] = Calendar_CustomFile.iloc[:,[4]].fillna('Unknown')
Calendar_CustomFile = Calendar_CustomFile.fillna('')


for row in range(0,Calendar_CustomFile.shape[0]):
    InsertStatement += 'INSERT INTO Calendar_Custom (Custom_Ref,Case_ID,Custom_Type)\nVALUES'
    
    Custom_Ref = '\'' + str(Calendar_CustomFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Calendar_CustomFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Custom_Type = '\'' + str(Calendar_CustomFile.iloc[row,4]).replace('\'','\'\'') + '\''

    InsertStatement += '(' + Custom_Ref + Case_ID + Custom_Type + ');\n'



Witches_Meeting_Place = 'Witches_Meeting_Place.xlsx'
Witches_Meeting_PlaceFile = pd.read_excel(Witches_Meeting_Place)
Witches_Meeting_PlaceFile.iloc[:,[4]] = Witches_Meeting_PlaceFile.iloc[:,[4]].fillna('Unknown')
Witches_Meeting_PlaceFile = Witches_Meeting_PlaceFile.fillna('')


for row in range(0,Witches_Meeting_PlaceFile.shape[0]):
    InsertStatement += 'INSERT INTO Witches_Meeting_Place (Meeting_Place_Ref,Case_ID,Meeting_Place,Notes)\nVALUES'
    
    Meeting_Place_Ref = '\'' + str(Witches_Meeting_PlaceFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Witches_Meeting_PlaceFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Meeting_Place = '\'' + str(Witches_Meeting_PlaceFile.iloc[row,4]).replace('\'','\'\'') + '\', '
    if(Witches_Meeting_PlaceFile.iloc[row,6]==''):
        Notes = 'NULL'
    else:
        Notes = '\'' + str(Witches_Meeting_PlaceFile.iloc[row,6]).replace('\'','\'\'') + '\''
    
    InsertStatement += '(' + Meeting_Place_Ref + Case_ID + Meeting_Place + Notes + ');\n'




Other_Charges = 'Other_Charges.xlsx'
Other_ChargesFile = pd.read_excel(Other_Charges)
Other_ChargesFile.iloc[:,[4]] = Other_ChargesFile.iloc[:,[4]].fillna('Unknown')
Other_ChargesFile = Other_ChargesFile.fillna('')


for row in range(0,Other_ChargesFile.shape[0]):
    InsertStatement += 'INSERT INTO Other_Charges (Other_Charges_Ref,Case_ID,Other_Charges_Type)\nVALUES'
    
    Other_Charges_Ref = '\'' + str(Other_ChargesFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Other_ChargesFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Other_Charges_Type = '\'' + str(Other_ChargesFile.iloc[row,4]).replace('\'','\'\'') + '\''


    
    InsertStatement += '(' + Other_Charges_Ref + Case_ID + Other_Charges_Type + ');\n'



print(InsertStatement)
