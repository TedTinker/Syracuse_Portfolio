# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import pandas as pd
from dateutil import parser

default_date = parser.parse('1/1/1400')


os.chdir('C:\\Users\\tedjt\\Desktop\\School\\Analysis\\WitchCraft')

Person = 'Person.xlsx'
PersonFile = pd.read_excel(Person)
PersonFile.iloc[:,[3, 4, 7,9]] = PersonFile.iloc[:,[3, 4, 7,9]].fillna('Unknown')
PersonFile = PersonFile.fillna('')

InsertStatement = ''

for row in range(0,PersonFile.shape[0]):
    InsertStatement += 'INSERT INTO Person ( Person_Ref,First_Name,Last_Name,Title,Occupation,Office,Residence,Notes1,Notes2)\nVALUES'
    
    Person_Ref = '\'' + str(PersonFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    First_Name = '\'' + str(PersonFile.iloc[row,3]).replace('\'','\'\'') + '\', '
    Last_Name =  '\'' + str(PersonFile.iloc[row,4]).replace('\'','\'\'') + '\', '
    if(PersonFile.iloc[row,6]==''):
        Title = 'NULL, '
    else:
        Title = '\'' + str(PersonFile.iloc[row,6]).replace('\'','\'\'') + '\', '
    Occupation =  '\'' + str(PersonFile.iloc[row,7]).replace('\'','\'\'') + '\', '
    if(PersonFile.iloc[row,8]==''):
        Office = 'NULL, '
    else:
        Office = '\'' + str(PersonFile.iloc[row,8]).replace('\'','\'\'') + '\', '
    Residence =  '\'' + str(PersonFile.iloc[row,9]).replace('\'','\'\'') + '\', '
    if(PersonFile.iloc[row,5]==''):
        Notes1 = 'NULL, '
    else:
        Notes1 = '\'' + str(PersonFile.iloc[row,5]).replace('\'','\'\'') + '\', '
    if(PersonFile.iloc[row,11]==''):
        Notes2 = 'NULL'
    else:
        Notes2 = '\'' + str(PersonFile.iloc[row,11]).replace('\'','\'\'') + '\''    
    
    
    InsertStatement += '(' + Person_Ref + First_Name + Last_Name + Title + Occupation + Office + Residence + Notes1 + Notes2 + ');\n'
    
    
    
print(InsertStatement)