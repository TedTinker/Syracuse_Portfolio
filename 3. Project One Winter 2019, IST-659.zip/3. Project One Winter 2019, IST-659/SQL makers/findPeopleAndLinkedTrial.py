# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import pandas as pd
from dateutil import parser

default_date = parser.parse('1/1/1400')


os.chdir('C:\\Users\\tedjt\\Desktop\\School\\Analysis\\WitchCraft')

Case_Person = 'Case_Person.xlsx'
Case_PersonFile = pd.read_excel(Case_Person)
Case_PersonFile.iloc[:,[5]] = Case_PersonFile.iloc[:,[5]].fillna('Unknown')
Case_PersonFile = Case_PersonFile.fillna('')

InsertStatement = ''

for row in range(0,Case_PersonFile.shape[0]):
    InsertStatement += 'INSERT INTO Case_Person ( Case_Person_Ref,Case_ID, Person_ID,Involvement,Notes )\nVALUES'
    
    Case_Person_Ref = '\'' + str(Case_PersonFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Case_PersonFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    if(Case_PersonFile.iloc[row,4]==''):
        Person_ID = 'NULL, '
    else:
        Person_ID = '(SELECT Person_ID FROM Person WHERE Person_Ref = \'' + str(Case_PersonFile.iloc[row,4]).replace('\'','\'\'') + '\'), '
    Involvement = '\'' + str(Case_PersonFile.iloc[row,5]).replace('\'','\'\'') + '\', '
    if(Case_PersonFile.iloc[row,6]==''):
        Notes = 'NULL'
    else:
        Notes = '\'' + str(Case_PersonFile.iloc[row,6]).replace('\'','\'\'') + '\''


    
    InsertStatement += '(' + Case_Person_Ref + Case_ID + Person_ID + Involvement + Notes + ');\n'
    
    
    
    
    
Trial_Person = 'Trial_Person.xlsx'
Trial_PersonFile = pd.read_excel(Trial_Person)
Trial_PersonFile.iloc[:,[6]] = Trial_PersonFile.iloc[:,[6]].fillna('Unknown')
Trial_PersonFile = Trial_PersonFile.fillna('')
    
for row in range(0,Trial_PersonFile.shape[0]):
    InsertStatement += 'INSERT INTO Trial_Person ( Trial_Person_Ref, Trial_ID, Person_ID, Case_ID, Involvement )\nVALUES'
    
    Trial_Person_Ref = '\'' + str(Trial_PersonFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(Trial_PersonFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    
    if(Trial_PersonFile.iloc[row,4]==''):
        Person_ID = 'NULL, '
    else:
        Person_ID = '(SELECT Person_ID FROM Person WHERE Person_Ref = \'' + str(Trial_PersonFile.iloc[row,4]).replace('\'','\'\'') + '\'), '
    Case_ID = '(SELECT Case_ID FROM theCase WHERE Case_Ref = \'' + str(Trial_PersonFile.iloc[row,5]).replace('\'','\'\'') + '\'), '
    Involvement = '\'' + str(Trial_PersonFile.iloc[row,6]).replace('\'','\'\'') + '\''    
    
    InsertStatement += '(' + Trial_Person_Ref + Trial_ID + Person_ID + Case_ID + Involvement + ');\n'
    




Linked_Trial = 'Linked_Trial.xlsx'
Linked_TrialFile = pd.read_excel(Linked_Trial)
Linked_TrialFile = Linked_TrialFile.fillna('')


    
for row in range(0,Linked_TrialFile.shape[0]):
    InsertStatement += 'INSERT INTO Linked_Trial (Trial_ID_1, Trial_ID_2 )\nVALUES'
    
    Trial_ID_1 = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(Linked_TrialFile.iloc[row,0]).replace('\'','\'\'') + '\'), '
    Trial_ID_2 = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(Linked_TrialFile.iloc[row,1]).replace('\'','\'\'') + '\')'

    
    InsertStatement += '(' + Trial_ID_1 + Trial_ID_2 + ');\n'
    
    
print(InsertStatement)