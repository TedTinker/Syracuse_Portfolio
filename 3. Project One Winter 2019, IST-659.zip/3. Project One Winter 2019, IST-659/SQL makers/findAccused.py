# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import pandas as pd

os.chdir('C:\\Users\\tedjt\\Desktop\\School\\Analysis\\WitchCraft')

Accused = 'Accused.xlsx'
AccusedFile = pd.read_excel(Accused)
AccusedFile.iloc[:,[3,4,5,6,14,16,17,18,22,23,24,25]] = AccusedFile.iloc[:,[3,4,5,6,14,16,17,18,22,23,24,25]].fillna('Unknown')
AccusedFile.iloc[:,[10]] = AccusedFile.iloc[:,[10]].fillna(0)
AccusedFile = AccusedFile.fillna('')

InsertStatement = ''

for row in range(0,AccusedFile.shape[0]):
    InsertStatement += 'INSERT INTO Accused (Accused_Ref,Parish_ID,First_Name,Last_Name,Maiden_First_Name,Maiden_Last_Name,Alias,Patronym,Title,Sex,Age,Settlement,Presbytery,County,Burgh,Ethnicity,Marital_Status,Socioeconomic_Status,Occupation,Notes)\nVALUES'
    Accused_Ref = '\'' + str(AccusedFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    if(AccusedFile.iloc[row,15]==''):
        Parish_ID = 'NULL, '
    else:
        Parish_ID = '(SELECT Parish_ID FROM Ref_Parish WHERE Parish_Ref = \'' + str(AccusedFile.iloc[row,15]).replace('\'','\'\'') + '\'), '
    First_Name = '\'' + str(AccusedFile.iloc[row,3]).replace('\'','\'\'') + '\', '
    Last_Name = '\'' + str(AccusedFile.iloc[row,4]).replace('\'','\'\'') + '\', '
    Maiden_First_Name = '\'' + str(AccusedFile.iloc[row,5]).replace('\'','\'\'') + '\', '
    Maiden_Last_Name = '\'' + str(AccusedFile.iloc[row,6]).replace('\'','\'\'') + '\', '
    if(AccusedFile.iloc[row,7]==''):
        Alias = 'NULL, '
    else:
        Alias = '\'' + str(AccusedFile.iloc[row,7]).replace('\'','\'\'') + '\', '
    if(AccusedFile.iloc[row,8]==''):
        Patronym = 'NULL, '
    else:
        Patronym = '\'' + str(AccusedFile.iloc[row,8]).replace('\'','\'\'') + '\', '
    if(AccusedFile.iloc[row,9]==''):
        Title = 'NULL, '
    else:
        Title = '\'' + str(AccusedFile.iloc[row,9]).replace('\'','\'\'') + '\', '
    if(str(AccusedFile.iloc[row,10])=='Female'):
        Sex = str(0)
    else:
        Sex = str(1)
    if(AccusedFile.iloc[row,11]==''):
        Age = 'NULL'
    else:
        Age = str(AccusedFile.iloc[row,11]).replace('\'','\'\'') 
    Settlement = '\'' + str(AccusedFile.iloc[row,14]).replace('\'','\'\'') + '\', '
    Presbytery = '\'' + str(AccusedFile.iloc[row,16]).replace('\'','\'\'') + '\', '
    County = '\'' + str(AccusedFile.iloc[row,17]).replace('\'','\'\'') + '\', '
    Burgh = '\'' + str(AccusedFile.iloc[row,18]).replace('\'','\'\'') + '\', '
    Ethnicity = '\'' + str(AccusedFile.iloc[row,22]).replace('\'','\'\'') + '\', '
    Marital_Status = '\'' + str(AccusedFile.iloc[row,23]).replace('\'','\'\'') + '\', '
    Socioeconomic_Status = '\'' + str(AccusedFile.iloc[row,24]).replace('\'','\'\'') + '\', '
    if(AccusedFile.iloc[row,25]==''):
        Occupation = 'NULL, '
    else:
        Occupation = '\'' + str(AccusedFile.iloc[row,25]).replace('\'','\'\'') + '\', '
    if(AccusedFile.iloc[row,26]==''):
        Notes = 'NULL'
    else:
        Notes = '\'' + str(AccusedFile.iloc[row,26]).replace('\'','\'\'') + '\''
    InsertStatement += '(' + Accused_Ref + Parish_ID + First_Name + Last_Name + Maiden_First_Name + Maiden_Last_Name + Alias + Patronym + Title + Sex + ', ' + Age + ', ' + Settlement + Presbytery + County + Burgh + Ethnicity + Marital_Status + Socioeconomic_Status + Occupation + Notes + ');\n'
    



Accused_Family = 'Accused_Family.xlsx'
Accused_FamilyFile = pd.read_excel(Accused_Family)
Accused_FamilyFile.iloc[:,[13,4,3,12]] = Accused_FamilyFile.iloc[:,[13,4,3,12]].fillna('Unknown')
Accused_FamilyFile = Accused_FamilyFile.fillna('')


for row in range(0,Accused_FamilyFile.shape[0]):
    InsertStatement += 'INSERT INTO Accused_Family ( Accused_Family_Ref, Accused_ID,Relationship,First_Name,Last_Name,Alias,Patronym,Title,Age,Occupation)\nVALUES'
    
    Accused_Family_Ref = '\'' + str(Accused_FamilyFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Accused_ID = '(SELECT Accused_ID FROM Accused WHERE Accused_Ref = \'' + str(Accused_FamilyFile.iloc[row,14]).replace('\'','\'\'') + '\'), '
    Relationship = '\'' + str(Accused_FamilyFile.iloc[row,13]).replace('\'','\'\'') + '\', '
    First_Name = '\'' + str(Accused_FamilyFile.iloc[row,4]).replace('\'','\'\'') + '\', '
    Last_Name = '\'' + str(Accused_FamilyFile.iloc[row,3]).replace('\'','\'\'') + '\', '
    if(Accused_FamilyFile.iloc[row,5]==''):
        Alias = 'NULL, '
    else:
        Alias = '\'' + str(Accused_FamilyFile.iloc[row,5]).replace('\'','\'\'') + '\', '
    if(Accused_FamilyFile.iloc[row,6]==''):
        Patronym = 'NULL, '
    else:
        Patronym = '\'' + str(Accused_FamilyFile.iloc[row,6]).replace('\'','\'\'') + '\', '
    if(Accused_FamilyFile.iloc[row,7]==''):
        Title = 'NULL, '
    else:
        Title = '\'' + str(Accused_FamilyFile.iloc[row,7]).replace('\'','\'\'') + '\', '
    if(Accused_FamilyFile.iloc[row,9]==''):
        Age = 'NULL, '
    else:
        Age = str(Accused_FamilyFile.iloc[row,9]).replace('\'','\'\'') + ', '
    Occupation = '\'' + str(Accused_FamilyFile.iloc[row,12]).replace('\'','\'\'') + '\''


    InsertStatement += '(' + Accused_Family_Ref+Accused_ID+Relationship+First_Name + Last_Name + Alias + Patronym + Title + Age + Occupation + ');\n'
    
    
    
    
print(InsertStatement)