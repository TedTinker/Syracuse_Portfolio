# -*- coding: utf-8 -*-
"""
Created on Fri Feb 22 20:31:51 2019

@author: tedjt
"""

import os
import pandas as pd
from dateutil import parser

default_date = parser.parse('1/1/1400')


os.chdir('C:\\Users\\tedjt\\Desktop\\School\\Analysis\\WitchCraft')

Trial = 'Trial.xlsx'
TrialFile = pd.read_excel(Trial)
TrialFile.iloc[:,[32,37]] = TrialFile.iloc[:,[32,37]].fillna('Unknown')
TrialFile.iloc[:,[33,34]] = TrialFile.iloc[:,[33,34]].fillna(0)
TrialFile = TrialFile.fillna('')


print(TrialFile.iloc[1,16])


print(TrialFile.iloc[1,16]==FALSE)
