# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import pandas as pd
from dateutil import parser

default_date = parser.parse('1/1/1400')

os.chdir('C:\\Users\\tedjt\\Desktop\\School\\Analysis\\WitchCraft')

Case = 'Case.xlsx'
CaseFile = pd.read_excel(Case)
CaseFile.iloc[:,[10]] = CaseFile.iloc[:,[10]].fillna('Unknown')
#CaseFile.iloc[:,[4,6,9,52,54,66,77,106]] = CaseFile.iloc[:,[4,6,9,52,54,66,77,106]].fillna('NULL')
CaseFile = CaseFile.fillna('')

InsertStatement = ''

for row in range(0,CaseFile.shape[0]):
    InsertStatement += 'INSERT INTO theCase (Case_Ref,Accused_ID,Start_Date,Case_Date,Age_at_Case,Case_Common_Name,Char_Notes,Disease_Notes,Other_Maleficia_Notes,Devil_Notes,Meeting_Notes,Folk_Notes,Case_Notes)\nVALUES'
    Case_Ref = '\'' + str(CaseFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    if(CaseFile.iloc[row,4]==''):
        Accused_ID = 'NULL, '
    else:
        Accused_ID = '(SELECT Accused_ID FROM Accused WHERE Accused_Ref = \'' + str(CaseFile.iloc[row,4]).replace('\'','\'\'') + '\'), '
    if(CaseFile.iloc[row,5]==''):
        Start_Date = 'NULL, '
    else:
        Start_Date = '\'' + str(parser.parse(str(CaseFile.iloc[row,5]).replace('\'','\'\''), default=default_date).date()) + '\', '
    if(CaseFile.iloc[row,7]==''):
        Case_Date = 'NULL, '
    else:
        Case_Date = '\'' + str(parser.parse(str(CaseFile.iloc[row,7]).replace('\'','\'\''), default=default_date).date()) + '\', '
    if(CaseFile.iloc[row,9]==''):
        Age_at_Case = 'NULL, '
    else:
        Age_at_Case = str(CaseFile.iloc[row,9]).replace('\'','\'\'') + ', '
    Case_Common_Name = '\'' + str(CaseFile.iloc[row,10]).replace('\'','\'\'') + '\', '
    if(CaseFile.iloc[row,52]==''):
        Char_Notes = 'NULL, '
    else:
        Char_Notes = '\'' + str(CaseFile.iloc[row,52]).replace('\'','\'\'') + '\', '
    if(CaseFile.iloc[row,95]==''):
        Disease_Notes = 'NULL, '
    else:
        Disease_Notes = '\'' + str(CaseFile.iloc[row,95]).replace('\'','\'\'') + '\', '
    if(CaseFile.iloc[row,98]==''):
        Other_Maleficia_Notes = 'NULL, '
    else:
        Other_Maleficia_Notes = '\'' + str(CaseFile.iloc[row,98]).replace('\'','\'\'') + '\', '
    if(CaseFile.iloc[row,54]==''):
        Devil_Notes = 'NULL, '
    else:
        Devil_Notes = '\'' + str(CaseFile.iloc[row,54]).replace('\'','\'\'') + '\', '
    if(CaseFile.iloc[row,66]==''):
        Meeting_Notes = 'NULL, '
    else:
        Meeting_Notes = '\'' + str(CaseFile.iloc[row,66]).replace('\'','\'\'') + '\', '
    if(CaseFile.iloc[row,77]==''):
        Folk_Notes = 'NULL, '
    else:
        Folk_Notes = '\'' + str(CaseFile.iloc[row,77]).replace('\'','\'\'') + '\', '
    
    if(CaseFile.iloc[row,106]==''):
        Case_Notes = 'NULL'
    else:
        Case_Notes = '\'' + str(CaseFile.iloc[row,106]).replace('\'','\'\'') + '\''
    
    InsertStatement += '(' + Case_Ref + Accused_ID + Start_Date + Case_Date + Age_at_Case + Case_Common_Name + Char_Notes  + Disease_Notes + Other_Maleficia_Notes + Devil_Notes + Meeting_Notes + Folk_Notes + Case_Notes + ');\n'
    
print(InsertStatement)





