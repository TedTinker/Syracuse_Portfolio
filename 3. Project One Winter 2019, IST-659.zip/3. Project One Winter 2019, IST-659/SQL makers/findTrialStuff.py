# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import pandas as pd
from dateutil import parser

default_date = parser.parse('1/1/1400')

os.chdir('C:\\Users\\tedjt\\Desktop\\School\\Analysis\\WitchCraft')




Commission = 'Commission.xlsx'
CommissionFile = pd.read_excel(Commission)
CommissionFile.iloc[:,[4,5]] = CommissionFile.iloc[:,[4,5]].fillna('Unknown')
CommissionFile.iloc[:,[9]] = CommissionFile.iloc[:,[]].fillna(0)
CommissionFile = CommissionFile.fillna('')

InsertStatement = ''

for row in range(0,CommissionFile.shape[0]):
    InsertStatement += 'INSERT INTO Commission (Commission_Ref,Trial_ID,Comm_Body,Comm_Type,Comm_Date,Sealed,Notes)\nVALUES'
    
    Commission_Ref = '\'' + str(CommissionFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(CommissionFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Comm_Body = '\'' + str(CommissionFile.iloc[row,4]).replace('\'','\'\'') + '\', '
    Comm_Type = '\'' + str(CommissionFile.iloc[row,5]).replace('\'','\'\'') + '\', '
    if(CommissionFile.iloc[row,7]==''):
        Comm_Date = 'NULL, '
    else:
        Comm_Date = '\'' + str(parser.parse(str(CommissionFile.iloc[row,7]).replace('\'','\'\''), default=default_date).date()) + '\', '
    if(str(CommissionFile.iloc[row,9])=='0'):
        Sealed = str(0) + ', '
    else:
        Sealed = str(1)  + ', '
    if(CommissionFile.iloc[row,10]==''):
        Notes = 'NULL'
    else:
        Notes = '\'' + str(CommissionFile.iloc[row,10]).replace('\'','\'\'') + '\''
    
    InsertStatement += '(' + Commission_Ref + Trial_ID + Comm_Body + Comm_Type + Comm_Date + Sealed + Notes + ');\n'
    
    


Moves_to_HLA = 'Moves_to_HLA.xlsx'
Moves_to_HLAFile = pd.read_excel(Moves_to_HLA)
Moves_to_HLAFile.iloc[:,[4]] = Moves_to_HLAFile.iloc[:,[4]].fillna('Unknown')
Moves_to_HLAFile = Moves_to_HLAFile.fillna('')

for row in range(0,Moves_to_HLAFile.shape[0]):
    InsertStatement += 'INSERT INTO Moves_to_HLA (Move_Ref,Trial_ID,Move_to,Move_Date)\nVALUES'
    
    Move_Ref = '\'' + str(Moves_to_HLAFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(Moves_to_HLAFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Move_to = '\'' + str(Moves_to_HLAFile.iloc[row,4]).replace('\'','\'\'') + '\', '
    if(Moves_to_HLAFile.iloc[row,6]==''):
        Move_Date = 'NULL'
    else:
        Move_Date = '\'' + str(parser.parse(str(Moves_to_HLAFile.iloc[row,6]).replace('\'','\'\''), default=default_date).date()) + '\''
    
    InsertStatement += '(' + Move_Ref + Trial_ID + Move_to + Move_Date + ');\n'
    
    
    
    
    
    
Appeal = 'Appeal.xlsx'
AppealFile = pd.read_excel(Appeal)
AppealFile.iloc[:,[5,6]] = AppealFile.iloc[:,[5,6]].fillna('Unknown')
AppealFile = AppealFile.fillna('')

for row in range(0,AppealFile.shape[0]):
    InsertStatement += 'INSERT INTO Appeal (Appeal_Ref,Trial_ID,Central_Authority, Reason, Date)\nVALUES'
    
    Appeal_Ref = '\'' + str(AppealFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(AppealFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Central_Authority = '\'' + str(AppealFile.iloc[row,5]).replace('\'','\'\'') + '\', '
    Reason = '\'' + str(AppealFile.iloc[row,6]).replace('\'','\'\'') + '\', '
    if(AppealFile.iloc[row,8]==''):
        Date = 'NULL'
    else:
        Date = '\'' + str(parser.parse(str(AppealFile.iloc[row,8]).replace('\'','\'\''), default=default_date).date()) + '\''    
    
    InsertStatement += '(' + Appeal_Ref + Trial_ID + Central_Authority + Reason + Date + ');\n'
    
    


Confession = 'Confession.xlsx'
ConfessionFile = pd.read_excel(Confession)
ConfessionFile.iloc[:,[9,8]] = ConfessionFile.iloc[:,[9,8]].fillna('Unknown')
ConfessionFile = ConfessionFile.fillna('')

for row in range(0,ConfessionFile.shape[0]):
    InsertStatement += 'INSERT INTO Confession (Confession_Ref,Trial_ID,Confession_Date,Confession_Location,Confession_Place)\nVALUES'
    
    Confession_Ref = '\'' + str(ConfessionFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(ConfessionFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    if(ConfessionFile.iloc[row,6]==''):
        Confession_Date = 'NULL,'
    else:
        Confession_Date = '\'' + str(parser.parse(str(ConfessionFile.iloc[row,6]).replace('\'','\'\''), default=default_date).date()) + '\','
    Confession_Location = '\'' + str(ConfessionFile.iloc[row,9]).replace('\'','\'\'') + '\', '
    Confession_Place = '\'' + str(ConfessionFile.iloc[row,8]).replace('\'','\'\'') + '\''

    InsertStatement += '(' + Confession_Ref + Trial_ID + Confession_Date + Confession_Location + Confession_Place + ');\n'
    
    
    
    
    
Denunciation = 'Denunciation.xlsx'
DenunciationFile = pd.read_excel(Denunciation)
DenunciationFile = DenunciationFile.fillna('')

for row in range(0,DenunciationFile.shape[0]):
    InsertStatement += 'INSERT INTO Denunciation (Denunc_Ref,Trial_ID,Denunc_Date,Notes)\nVALUES'
    
    Denunc_Ref = '\'' + str(DenunciationFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(DenunciationFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    if(DenunciationFile.iloc[row,5]==''):
        Denunc_Date = 'NULL, '
    else:
        Denunc_Date = '\'' + str(parser.parse(str(DenunciationFile.iloc[row,5]).replace('\'','\'\''), default=default_date).date()) + '\', '
    if(DenunciationFile.iloc[row,7]==''):
        Notes = 'NULL'
    else:
        Notes = '\'' + str(DenunciationFile.iloc[row,7]).replace('\'','\'\'') + '\''
    
    InsertStatement += '(' + Denunc_Ref + Trial_ID + Denunc_Date + Notes + ');\n'
    
    


Imprisonment = 'Imprisonment.xlsx'
ImprisonmentFile = pd.read_excel(Imprisonment)
ImprisonmentFile.iloc[:,[7, 8, 10]] = ImprisonmentFile.iloc[:,[]].fillna('Unknown')
ImprisonmentFile.iloc[:,[9]] = ImprisonmentFile.iloc[:,[]].fillna(0)
ImprisonmentFile = ImprisonmentFile.fillna('')

for row in range(0,ImprisonmentFile.shape[0]):
    InsertStatement += 'INSERT INTO Imprisonment (Imprison_Ref,Trial_ID,Imprison_Date,Prison,Location,Moved,Fate)\nVALUES'
    
    Imprison_Ref = '\'' + str(ImprisonmentFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(ImprisonmentFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    if(ImprisonmentFile.iloc[row,5]==''):
        Imprison_Date = 'NULL, '
    else:
        Imprison_Date = '\'' + str(parser.parse(str(ImprisonmentFile.iloc[row,5]).replace('\'','\'\''), default=default_date).date()) + '\', '
    Prison = '\'' + str(ImprisonmentFile.iloc[row,7]).replace('\'','\'\'') + '\', '
    Location = '\'' + str(ImprisonmentFile.iloc[row,8]).replace('\'','\'\'') + '\', '
    if(str(ImprisonmentFile.iloc[row,9])=='FALSE'):
        Moved = str(0)  + ', '
    else:
        Moved = str(1)  + ', '
    Fate = '\'' + str(ImprisonmentFile.iloc[row,10]).replace('\'','\'\'') + '\''

    InsertStatement += '(' + Imprison_Ref + Trial_ID + Imprison_Date + Prison + Location + Moved + Fate + ');\n'
    
    
    
    
    
    
Ordeal = 'Ordeal.xlsx'
OrdealFile = pd.read_excel(Ordeal)
OrdealFile.iloc[:,[7]] = OrdealFile.iloc[:,[7]].fillna('Unknown')
OrdealFile = OrdealFile.fillna('')

for row in range(0,OrdealFile.shape[0]):
    InsertStatement += 'INSERT INTO Ordeal (Ordeal_Ref,Trial_ID,Ordeal_Type,Ordeal_Date)\nVALUES'
    
    Ordeal_Ref = '\'' + str(OrdealFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(OrdealFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Ordeal_Type = '\'' + str(OrdealFile.iloc[row,7]).replace('\'','\'\'') + '\', '
    if(OrdealFile.iloc[row,5]==''):
        Ordeal_Date = 'NULL'
    else:
        Ordeal_Date = '\'' + str(parser.parse(str(OrdealFile.iloc[row,5]).replace('\'','\'\''), default=default_date).date()) + '\''
 
    InsertStatement += '(' + Ordeal_Ref + Trial_ID + Ordeal_Type + Ordeal_Date + ');\n'
    
    


Torture = 'Torture.xlsx'
TortureFile = pd.read_excel(Torture)
TortureFile.iloc[:,[7]] = TortureFile.iloc[:,[7]].fillna('Unknown')
TortureFile = TortureFile.fillna('')

for row in range(0,TortureFile.shape[0]):
    InsertStatement += 'INSERT INTO Torture (Torture_Ref,Trial_ID,Torture_Type,Torture_Date)\nVALUES'
    
    Torture_Ref = '\'' + str(TortureFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(TortureFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Torture_Type = '\'' + str(TortureFile.iloc[row,7]).replace('\'','\'\'') + '\', '
    if(TortureFile.iloc[row,5]==''):
        Torture_Date = 'NULL'
    else:
        Torture_Date = '\'' + str(parser.parse(str(TortureFile.iloc[row,5]).replace('\'','\'\''), default=default_date).date()) + '\''
    
    InsertStatement += '(' + Torture_Ref + Trial_ID + Torture_Type + Torture_Date + ');\n'
    
    
    
    
    
    
Mentioned_as_a_Witch = 'Mentioned_as_a_Witch.xlsx'
Mentioned_as_a_WitchFile = pd.read_excel(Mentioned_as_a_Witch)
Mentioned_as_a_WitchFile.iloc[:,[6,8,9,13]] = Mentioned_as_a_WitchFile.iloc[:,[6,8,9,13]].fillna('Unknown')
Mentioned_as_a_WitchFile = Mentioned_as_a_WitchFile.fillna('')

for row in range(0,Mentioned_as_a_WitchFile.shape[0]):
    InsertStatement += 'INSERT INTO Mentioned_as_a_Witch (Mention_Ref,Trial_ID,Trial_of_Accused_ID,Mentioned_in_Trial_ID,Mention_Date,Mentioned_Trial_Date,Mention_Type,Trial_of_First_Name,Trial_of_Last_Name,Fate_of_Mentioned,Notes)\nVALUES'
        
    Mention_Ref = '\'' + str(Mentioned_as_a_WitchFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(Mentioned_as_a_WitchFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Trial_of_Accused_ID = '(SELECT Accused_ID FROM Accused WHERE Accused_Ref = \'' + str(Mentioned_as_a_WitchFile.iloc[row,7]).replace('\'','\'\'') + '\'), '
    Mentioned_in_Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(Mentioned_as_a_WitchFile.iloc[row,10]).replace('\'','\'\'') + '\'), '
    if(Mentioned_as_a_WitchFile.iloc[row,4]==''):
        Mention_Date = 'NULL, '
    else:
        Mention_Date = '\'' + str(parser.parse(str(Mentioned_as_a_WitchFile.iloc[row,4]).replace('\'','\'\''), default=default_date).date()) + '\', '
    if(Mentioned_as_a_WitchFile.iloc[row,11]==''):
        Mentioned_Trial_Date = 'NULL, '
    else:
        Mentioned_Trial_Date = '\'' + str(parser.parse(str(Mentioned_as_a_WitchFile.iloc[row,11]).replace('\'','\'\''), default=default_date).date()) + '\', '
    Mention_Type = '\'' + str(Mentioned_as_a_WitchFile.iloc[row,6]).replace('\'','\'\'') + '\', '
    Trial_of_First_Name = '\'' + str(Mentioned_as_a_WitchFile.iloc[row,8]).replace('\'','\'\'') + '\', '
    Trial_of_Last_Name = '\'' + str(Mentioned_as_a_WitchFile.iloc[row,9]).replace('\'','\'\'') + '\', '
    Fate_of_Mentioned = '\'' + str(Mentioned_as_a_WitchFile.iloc[row,13]).replace('\'','\'\'') + '\', '
    if(Mentioned_as_a_WitchFile.iloc[row,14]==''):
        Notes = 'NULL'
    else:
        Notes = '\'' + str(Mentioned_as_a_WitchFile.iloc[row,14]).replace('\'','\'\'') + '\''

    
    
    InsertStatement += '(' + Mention_Ref + Trial_ID + Trial_of_Accused_ID + Mentioned_in_Trial_ID + Mention_Date + Mentioned_Trial_Date + Mention_Type + Trial_of_First_Name + Trial_of_Last_Name + Fate_of_Mentioned + Notes + ');\n'
    
    


Other_Named_Witch = 'Other_Named_Witch.xlsx'
Other_Named_WitchFile = pd.read_excel(Other_Named_Witch)
Other_Named_WitchFile.iloc[:,[4,6,7]] = Other_Named_WitchFile.iloc[:,[4,6,7]].fillna('Unknown')
Other_Named_WitchFile = Other_Named_WitchFile.fillna('')

for row in range(0,Other_Named_WitchFile.shape[0]):
    InsertStatement += 'INSERT INTO Other_Named_Witch (Named_Witch_Ref,Trial_ID,Named_in_Trial_ID,Named_Witch_Accused_ID,Mention_Type,First_Name,Last_Name,Date_of_Named_Witch_Trial,Notes)\nVALUES'
    
    print(row)
    
    Named_Witch_Ref = '\'' + str(Other_Named_WitchFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(Other_Named_WitchFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    Named_in_Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(Other_Named_WitchFile.iloc[row,8]).replace('\'','\'\'') + '\'), '
    Named_Witch_Accused_ID = '(SELECT Accused_ID FROM Accused WHERE Accused_Ref = \'' + str(Other_Named_WitchFile.iloc[row,5]).replace('\'','\'\'') + '\'), '
    Mention_Type = '\'' + str(Other_Named_WitchFile.iloc[row,4]).replace('\'','\'\'') + '\', '
    First_Name = '\'' + str(Other_Named_WitchFile.iloc[row,6]).replace('\'','\'\'') + '\', '
    Last_Name = '\'' + str(Other_Named_WitchFile.iloc[row,7]).replace('\'','\'\'') + '\', '
    if(Other_Named_WitchFile.iloc[row,9]==''):
        Date_of_Named_Witch_Trial = 'NULL, '
    else:
        Date_of_Named_Witch_Trial = '\'' + str(parser.parse(str(Other_Named_WitchFile.iloc[row,9]).replace('\'','\'\''), default=default_date).date()) + '\', '
    if(Other_Named_WitchFile.iloc[row,11]==''):
        Notes = 'NULL'
    else:
        Notes = '\'' + str(Other_Named_WitchFile.iloc[row,11]).replace('\'','\'\'') + '\''
    
    InsertStatement += '(' + Named_Witch_Ref + Trial_ID + Named_in_Trial_ID + Named_Witch_Accused_ID + Mention_Type + First_Name + Last_Name + Date_of_Named_Witch_Trial + Notes + ');\n'
    
    
    
    
    
    
Complaint = 'Complaint.xlsx'
ComplaintFile = pd.read_excel(Complaint)
ComplaintFile.iloc[:,[5,8]] = ComplaintFile.iloc[:,[5,8]].fillna('Unknown')
ComplaintFile = ComplaintFile.fillna('')

for row in range(0,ComplaintFile.shape[0]):
    InsertStatement += 'INSERT INTO Complaint (Complaint_Ref,Trial_ID,Accused_Family_ID,Person_ID,Complainer,Complaint_Date,Complaint_Place)\nVALUES'
    
    Complaint_Ref = '\'' + str(ComplaintFile.iloc[row,0]).replace('\'','\'\'') + '\', '
    Trial_ID = '(SELECT Trial_ID FROM Trial WHERE Trial_Ref = \'' + str(ComplaintFile.iloc[row,3]).replace('\'','\'\'') + '\'), '
    if(ComplaintFile.iloc[row,9]==''):
        Accused_Family_ID = 'NULL,'
    else:
        Accused_Family_ID = '(SELECT Accused_Family_ID FROM Accused_Family WHERE Accused_Family_Ref = \'' + str(ComplaintFile.iloc[row,9]).replace('\'','\'\'') + '\'), '
    if(ComplaintFile.iloc[row,10]==''):
        Person_ID = 'NULL,'
    else:
        Person_ID = '(SELECT Person_ID FROM Person WHERE Person_Ref = \'' + str(ComplaintFile.iloc[row,10]).replace('\'','\'\'') + '\'), '
    Complainer = '\'' + str(ComplaintFile.iloc[row,5]).replace('\'','\'\'') + '\', '
    if(ComplaintFile.iloc[row,6]==''):
        Complaint_Date = 'NULL, '
    else:
        Complaint_Date = '\'' + str(parser.parse(str(ComplaintFile.iloc[row,6]).replace('\'','\'\''), default=default_date).date()) + '\', '
    Complaint_Place = '\'' + str(ComplaintFile.iloc[row,8]).replace('\'','\'\'') + '\''

    InsertStatement += '(' + Complaint_Ref + Trial_ID + Accused_Family_ID + Person_ID + Complainer + Complaint_Date + Complaint_Place + ');\n'
    
    
    
print(InsertStatement)
    
