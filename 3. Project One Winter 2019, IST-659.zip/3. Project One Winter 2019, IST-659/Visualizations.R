require(RODBC)
library(dplyr)

myconn <- odbcConnect("WitchTrials")

sqlSelectStatement <- 
  "SELECT * FROM Accused"

sqlResult <- sqlQuery(myconn, sqlSelectStatement)

colors = c("pink","blue")
hist(sqlResult$Sex, xlab = "Sex (0 = female, 1 = male)", main = "Sex of accused witches",col=colors)

hist(sqlResult$Age, xlab = "Estimated Age", main = "Age of accused witches")

levels(sqlResult$Title) <- c(levels(sqlResult$Title),"None") 

sqlResult$Title[is.na(sqlResult$Title)] <- "None"

count(sqlResult,Title)

odbcCloseAll()


