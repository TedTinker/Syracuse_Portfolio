The folder "data" holds the thirty-five datasets used for the project, which can be opened in Excel.
The PDF "Witch Trial Project" is the final report including all visualizations and depictions of data-structure.
The PNG "Conceptual Model" is a more legible version of the data-structure established.
The folder "SQL makers" consists of Python-files, executed in Spyder. These Python-files produced the SQL-code used in SSMS.
The R-Script "Visualizations", executed in R-Studio, created visualizations for the report with simple SQL-queries. 