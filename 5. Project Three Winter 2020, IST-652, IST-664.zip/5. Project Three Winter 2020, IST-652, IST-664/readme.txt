The folder "data" holds the two short-stories used for the project, which can be opened in any text editor.
The PDF "Ted_Tinker_Final_Project_Report" is the final report including all visualizations and discoveries about writing-style.
The IPYNB "text_analysis", executed in Jupyter Notebook, processed the text-data into visualizations and ran a CNN to generate text.